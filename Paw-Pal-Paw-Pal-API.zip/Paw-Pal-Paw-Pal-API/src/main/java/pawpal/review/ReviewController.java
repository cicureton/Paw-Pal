package pawpal.review;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    // Show all reviews
    @GetMapping("/all")
    public String getAllReviews(Model model) {
        List<Review> reviews = reviewService.getAllReviews();
        model.addAttribute("reviews", reviews);
        model.addAttribute("title", "All Reviews");
        return "review-list"; // Create review-list.ftlh
    }

    // Show form to create a review for a specific booking
    @GetMapping("/create/{bookingId}")
    public String showReviewForm(@PathVariable int bookingId, Model model) {
        model.addAttribute("bookingId", bookingId);
        model.addAttribute("review", new Review());
        return "review-create"; // Create review-create.ftlh
    }

    // Handle review submission (POST)
    @PostMapping("/create/{bookingId}")
    public String submitReview(@PathVariable int bookingId, @ModelAttribute Review review) {
        // Set booking ID related fields manually or through hidden inputs
        reviewService.addReview(review);
        return "redirect:/profile"; // After submitting a review
    }

    // View a specific review
    @GetMapping("/{id}")
    public String viewReview(@PathVariable int id, Model model) {
        Review review = reviewService.getReviewById(id).orElse(null);
        if (review == null) {
            return "redirect:/reviews/all"; // fallback
        }
        model.addAttribute("review", review);
        return "review-details"; // Create review-details.ftlh
    }

    // Show reviews by provider
    @GetMapping("/provider/{id}")
    public String getReviewsByProvider(@PathVariable int id, Model model) {
        List<Review> reviews = reviewService.getReviewsByProviderId(id);
        model.addAttribute("reviews", reviews);
        model.addAttribute("title", "Reviews for Provider #" + id);
        return "review-list";
    }

    // Delete review
    @GetMapping("/delete/{id}")
    public String deleteReview(@PathVariable int id) {
        reviewService.deleteReviewById(id);
        return "redirect:/reviews/all";
    }

    // Reply to a review (GET form)
    @GetMapping("/{id}/reply")
    public String showReplyForm(@PathVariable int id, Model model) {
        Review review = reviewService.getReviewById(id).orElse(null);
        if (review == null) return "redirect:/reviews/all";
        model.addAttribute("review", review);
        return "review-reply"; // You'll create this
    }

    // Handle reply submission
    @PostMapping("/{id}/reply")
    public String handleReply(@PathVariable int id, @RequestParam String reply) {
        reviewService.replyToReview(id, reply);
        return "redirect:/reviews/" + id;
    }

    // Report a review (GET to trigger)
    @GetMapping("/{id}/report")
    public String reportReview(@PathVariable int id) {
        reviewService.reportReview(id);
        return "redirect:/reviews/" + id;
    }
}
