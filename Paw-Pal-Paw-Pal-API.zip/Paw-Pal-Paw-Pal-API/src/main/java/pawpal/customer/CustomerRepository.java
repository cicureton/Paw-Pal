package pawpal.customer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    // ✅ Add this method to support login functionality
    Customer findByUsername(String username);
}
