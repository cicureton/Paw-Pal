package pawpal.customer;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CustomerController {

    @Autowired
    private CustomerService service;

    @GetMapping("/")
    public String showHomePage() {
        return "index"; // renders index.ftlh
    }


    // 🔷 Customer list view (optional)
    @GetMapping("/customer-list")
    public String viewCustomerList(Model model) {
        List<Customer> customers = service.getAllCustomers();
        model.addAttribute("customers", customers);
        return "customer-list"; // customer-list.ftlh
    }

    // 🟢 Signup form
    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup"; // signup.ftlh
    }

    // 🟢 Signup POST handler
    @PostMapping("/signup")
    public String registerCustomer(
            @RequestParam String fullname,
            @RequestParam String address,
            @RequestParam String petDetails,
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String confirmPassword,
            Model model
    ) {
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match.");
            return "signup";
        }

        if (service.getCustomerByUsername(username) != null) {
            model.addAttribute("error", "Username already taken.");
            return "signup";
        }

        Customer customer = new Customer();
        customer.setUserId(service.generateUserId());
        customer.setFullname(fullname);
        customer.setAddress(address);
        customer.setPetDetails(petDetails);
        customer.setUsername(username);
        customer.setPassword(password);

        service.addNewCustomer(customer);
        return "redirect:/signin";
    }

    // 🔵 Signin form
    @GetMapping("/signin")
    public String showSigninForm() {
        return "signin"; // signin.ftlh
    }

    // 🔵 Signin POST handler
    @PostMapping("/signin")
    public String handleSignin(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            Model model
    ) {
        Customer customer = service.authenticate(username, password);
        if (customer == null) {
            model.addAttribute("error", "Invalid username or password.");
            return "signin";
        }

        session.setAttribute("loggedInUser", customer);
        return "redirect:/profile";
    }

    // 🟣 Profile page
    @GetMapping("/profile")
    public String viewProfile(HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        model.addAttribute("user", user);
        return "profile"; // profile.ftlh
    }

    // 🟠 Edit profile form
    @GetMapping("/edit-profile")
    public String showEditProfileForm(HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        model.addAttribute("user", user);
        return "edit-profile"; // edit-profile.ftlh
    }

    // 🟠 Edit profile POST
    @PostMapping("/edit-profile")
    public String handleEditProfile(
            @RequestParam String fullname,
            @RequestParam String address,
            @RequestParam String petDetails,
            HttpSession session
    ) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        user.setFullname(fullname);
        user.setAddress(address);
        user.setPetDetails(petDetails);

        service.addNewCustomer(user); // save updates
        session.setAttribute("loggedInUser", user); // refresh session

        return "redirect:/profile";
    }

    // 🔴 Sign out
    @GetMapping("/signout")
    public String signOut(HttpSession session) {
        session.invalidate();
        return "redirect:/signin";
    }

    @GetMapping("/services")
    public String showServicesPage() {
        return "services"; // loads services.ftlh
    }
}
