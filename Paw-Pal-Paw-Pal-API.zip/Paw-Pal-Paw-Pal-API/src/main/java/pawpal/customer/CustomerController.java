package pawpal.customer;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CustomerController {

    @Autowired
    private CustomerService service;

    // 🏠 Homepage
    @GetMapping("/")
    public String showHomePage(HttpSession session, Model model) {
        Customer loggedInUser = (Customer) session.getAttribute("loggedInUser");
        model.addAttribute("loggedInUser", loggedInUser);
        return "index";
    }

    // 📋 View all customers
    @GetMapping("/customer-list")
    public String viewCustomerList(Model model) {
        List<Customer> customers = service.getAllCustomers();
        model.addAttribute("customers", customers);
        return "customer-list";
    }

    // 🟢 Show sign-up form
    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup";
    }

    // 🟢 Handle sign-up
    @PostMapping("/signup")
    public String handleSignup(
            @RequestParam String firstName,
            @RequestParam String lastName,
            @RequestParam String email,
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String confirmPassword,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String petDetails,
            HttpSession session,
            Model model
    ) {
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match.");
            return "signup";
        }

        if (service.usernameExists(username)) {
            model.addAttribute("error", "Username already taken.");
            return "signup";
        }

        if (service.emailExists(email)) {
            model.addAttribute("error", "Email already in use.");
            return "signup";
        }

        Customer customer = new Customer(
                service.generateUserId(),
                firstName,
                lastName,
                email,
                username,
                password,
                address,
                petDetails
        );

        service.addCustomer(customer);
        session.setAttribute("loggedInUser", customer);  // Auto-login after signup
        return "redirect:/";
    }

    // 🔵 Show sign-in form
    @GetMapping("/signin")
    public String showSigninForm() {
        return "signin";
    }

    // 🔵 Handle sign-in
    @PostMapping("/signin")
    public String handleSignin(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            Model model
    ) {
        Customer customer = service.authenticate(username, password);
        if (customer == null) {
            model.addAttribute("error", "Invalid username or password.");
            return "signin";
        }

        session.setAttribute("loggedInUser", customer);
        return "redirect:/";
    }

    // 👤 Show user profile
    @GetMapping("/profile")
    public String viewProfile(HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";
        model.addAttribute("user", user);
        return "profile";
    }

    // ✏️ Show edit form
    @GetMapping("/edit-profile")
    public String showEditProfileForm(HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        model.addAttribute("user", user);
        return "edit-profile";
    }

    // ✏️ Handle profile edit
    @PostMapping("/edit-profile")
    public String handleEditProfile(
            @RequestParam String firstName,
            @RequestParam String lastName,
            @RequestParam String email,
            @RequestParam String address,
            @RequestParam String petDetails,
            HttpSession session
    ) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setAddress(address);
        user.setPetDetails(petDetails);

        service.addCustomer(user); // update
        session.setAttribute("loggedInUser", user); // refresh session
        return "redirect:/profile";
    }

    // 🔴 Sign out
    @GetMapping("/signout")
    public String handleSignout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
