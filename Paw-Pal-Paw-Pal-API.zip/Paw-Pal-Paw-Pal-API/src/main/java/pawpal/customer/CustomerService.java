package pawpal.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(int id) {
        return customerRepository.findById(id).orElse(null);
    }

    public void addCustomer(Customer customer) {
        customerRepository.save(customer);
    }

    public void deleteCustomer(int id) {
        customerRepository.deleteById(id);
    }

    public Customer authenticate(String username, String password) {
        Customer customer = customerRepository.findByUsername(username);
        return (customer != null && customer.getPassword().equals(password)) ? customer : null;
    }

    public boolean usernameExists(String username) {
        return customerRepository.findByUsername(username) != null;
    }

    public boolean emailExists(String email) {
        return customerRepository.findByEmail(email) != null;
    }

    public int generateUserId() {
        return customerRepository.findAll().size() + 1;
    }
}
