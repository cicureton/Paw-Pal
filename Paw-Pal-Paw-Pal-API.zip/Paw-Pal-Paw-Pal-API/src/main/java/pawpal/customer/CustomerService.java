package pawpal.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // ✅ Get all customers
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    // ✅ Get one customer by ID
    public Customer getCustomerById(int customerId) {
        return customerRepository.findById(customerId).orElse(null);
    }

    // ✅ Add a new customer (used for signup)
    public void addNewCustomer(Customer customer) {
        customerRepository.save(customer);
    }

    // ✅ Update existing customer
    public void updateCustomer(int customerId, Customer customer) {
        Customer existing = getCustomerById(customerId);
        if (existing != null) {
            existing.setAddress(customer.getAddress());
            existing.setPetDetails(customer.getPetDetails());
            customerRepository.save(existing);
        }
    }

    // ✅ Delete customer by ID
    public void deleteCustomerById(int customerId) {
        customerRepository.deleteById(customerId);
    }

    // ✅ Authenticate customer by username and password
    public Customer authenticate(String username, String password) {
        Customer customer = customerRepository.findByUsername(username);
        if (customer != null && customer.getPassword().equals(password)) {
            return customer;
        }
        return null;
    }

    public Customer getCustomerByUsername(String username) {
        return customerRepository.findByUsername(username);
    }

    // 🔄 Optional: Generate a basic user ID (not needed if auto-incremented)
    public int generateUserId() {
        List<Customer> customers = customerRepository.findAll();
        return customers.size() + 1;
    }
}
