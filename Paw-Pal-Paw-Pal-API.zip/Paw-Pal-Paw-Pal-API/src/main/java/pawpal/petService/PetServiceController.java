package pawpal.petService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/services")
public class PetServiceController {

    @Autowired
    private PetServiceService petServiceService;

    // 🔍 View all services (and keep session)
    @GetMapping("/all")
    public String getAllServices(HttpSession session, Model model) {
        List<PetService> services = petServiceService.getAllServices();
        model.addAttribute("services", services);
        model.addAttribute("title", "All Pet Services");

        // ✅ Retain logged-in user (if any)
        Object loggedInUser = session.getAttribute("loggedInUser");
        model.addAttribute("loggedInUser", loggedInUser);

        return "service-list"; // service-list.ftlh
    }

    // (Optional) More handlers can be added here like create/update/delete
}
