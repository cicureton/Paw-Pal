package pawpal.petService;

import jakarta.persistence.*;
import pawpal.provider.Provider;

@Entity
@Table(name = "pet_services")
public class PetService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int serviceId;

    @ManyToOne
    @JoinColumn(name = "provider_id", nullable = false)
    private Provider provider;

    private String title;
    private String description;
    private float price;
    private String availability;

    public PetService() {}

    public PetService(Provider provider, String title, String description, float price, String availability) {
        this.provider = provider;
        this.title = title;
        this.description = description;
        this.price = price;
        this.availability = availability;
    }

    // Getters and setters

    public int getServiceId() { return serviceId; }
    public void setServiceId(int serviceId) { this.serviceId = serviceId; }

    public Provider getProvider() { return provider; }
    public void setProvider(Provider provider) { this.provider = provider; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public float getPrice() { return price; }
    public void setPrice(float price) { this.price = price; }

    public String getAvailability() { return availability; }
    public void setAvailability(String availability) { this.availability = availability; }

    @Override
    public String toString() {
        return "PetService{" +
                "serviceId=" + serviceId +
                ", provider=" + provider.getProviderId() +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", availability='" + availability + '\'' +
                '}';
    }
}
