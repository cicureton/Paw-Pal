package pawpal.booking;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import pawpal.customer.Customer;
import pawpal.review.Review;
import pawpal.review.ReviewService;
import pawpal.petService.PetService;
import pawpal.petService.PetServiceService;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private PetServiceService petServiceService;

    @Autowired
    private ReviewService reviewService;

    // Show all bookings for the logged-in user
    @GetMapping("/my")
    public String viewMyBookings(HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        List<Booking> bookings = bookingService.getBookingsByCustomerId(user.getCustomerId());
        model.addAttribute("bookings", bookings);
        return "booking-list"; // booking-list.ftlh
    }

    // Show booking form (used when selecting a service)
    @GetMapping("/create/{serviceId}")
    public String showBookingForm(@PathVariable int serviceId, HttpSession session, Model model) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        PetService service = petServiceService.getServiceById(serviceId).orElse(null);
        if (service == null) return "redirect:/services";

        model.addAttribute("service", service);
        model.addAttribute("booking", new Booking());
        return "booking-form"; // booking-form.ftlh
    }

    // Submit new booking
    @PostMapping("/submit")
    public String submitBooking(@ModelAttribute Booking booking, HttpSession session) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        booking.setCustomerId(user.getCustomerId());
        booking.setStatus("pending");
        booking.setAppointment(new Date()); // Placeholder - replace with real appointment selection
        bookingService.createBooking(booking);
        return "redirect:/profile";
    }

    // Leave a review for a booking
    @GetMapping("/review/{bookingId}")
    public String showReviewForm(@PathVariable int bookingId, Model model, HttpSession session) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        Booking booking = bookingService.getBookingById(bookingId).orElse(null);
        if (booking == null || booking.getCustomerId() != user.getCustomerId()) {
            return "redirect:/profile";
        }

        model.addAttribute("booking", booking);
        model.addAttribute("review", new Review());
        return "submit-review"; // submit-review.ftlh
    }

    @PostMapping("/review/{bookingId}")
    public String submitReview(@PathVariable int bookingId,
                               @RequestParam int rating,
                               @RequestParam String description,
                               HttpSession session) {
        Customer user = (Customer) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/signin";

        Booking booking = bookingService.getBookingById(bookingId).orElse(null);
        if (booking == null) return "redirect:/profile";

        Review review = new Review(
                user.getCustomerId(),
                booking.getProviderId(),
                booking.getServiceId(),
                rating,
                description,
                new Date()
        );
        reviewService.createReview(review);
        return "redirect:/profile";
    }
}
